package sample;

import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.transform.Translate;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class Controller2  implements Initializable {
    @FXML
    private Button GameMenu;

    public void InGame_Menu(ActionEvent act2) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Scene4.fxml"));
        Stage stage=(Stage) ((Node) act2.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();

    }

    @FXML
    private ImageView Hero;

    @FXML
    private  ImageView Orc;

    @FXML
    private ImageView BossOrc;

    @FXML
    private ImageView Hammer;



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        TranslateTransition animation1=new TranslateTransition();
        animation1.setNode(Hero);
        animation1.setDuration(Duration.millis(800));
        animation1.setByY(-40);
        animation1.setCycleCount(TranslateTransition.INDEFINITE);
        animation1.play();

        TranslateTransition animation2=new TranslateTransition();
        animation2.setNode(Orc);
        animation2.setDuration(Duration.millis(700));
        animation2.setByY(-35);
        animation2.setCycleCount(TranslateTransition.INDEFINITE);
        animation2.play();

        TranslateTransition animation3=new TranslateTransition();
        animation3.setNode(Hammer);
        animation3.setDuration(Duration.millis(800));
        animation3.setByX(+30);
        animation3.setByY(-35);
        animation3.setCycleCount(TranslateTransition.INDEFINITE);
        animation3.play();



    }


}
