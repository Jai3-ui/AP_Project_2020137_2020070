package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

//import java.awt.*;

public class Controller {
    @FXML
    private Button StartGame;

    @FXML
    private  Button Loading;

    @FXML
    private Button ExitGame;

    @FXML
    private AnchorPane Scene1;

    public  void Exit(ActionEvent event){
        Alert alert;
        alert=new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(" Exit ");
        alert.setHeaderText(" You are about to Exit the Game !!!");
        alert.setContentText(" Do You want to Exit from the Game ? ");
        if(alert.showAndWait().get()== ButtonType.OK){
            Stage stage;
            stage=(Stage) Scene1.getScene().getWindow();
            System.out.printf("You Exit From the Game");
            stage.close();
        }
    }

    public  void Start_Game(ActionEvent act) throws IOException {
      //  LabelText.setText(" You Started the Game ");
        StartGame.setStyle("fx-background-color: #33ccff");
        Parent root = FXMLLoader.load(getClass().getResource("Scene2.fxml"));
        Stage stage=(Stage) ((Node) act.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();

    }


    @FXML
    private Label Highlight;
    @FXML
    private Button Submission;
    @FXML
    private TextField Naming;

    public void Submit_Name(ActionEvent act1) throws IOException{
        Highlight.setText(" Hii "+Naming.getText()+" You can Now Play the Game!!!");
        Parent root = FXMLLoader.load(getClass().getResource("Scene3.fxml"));
        Stage stage=(Stage) ((Node) act1.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();

    }



    @FXML
    private  Button Exit;

    @FXML
    private AnchorPane Scene4;

    public void MainMenu(ActionEvent act3) throws  IOException{
        Alert alert;
        alert=new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(" Exit to Main Menu  ");
        alert.setHeaderText(" You are about to Exit to  the Main Menu !!!");
        alert.setContentText(" Do You want to Exit to the Main Menu ? ");
        if(alert.showAndWait().get()== ButtonType.OK){
            Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
            Stage stage=(Stage) ((Node) act3.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        }

    }
















}
